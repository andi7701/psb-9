
	<footer class="main-footer">
		<div class="pull-right hidden-xs">
			<b>Version</b> 1.0.0
		</div>
		<strong>@2018 Sekolah Alam Indonesia - Studio Alam.</strong> Hak cipta dilindungi Undang-Undang
	</footer>
</div>

<!-- jQuery UI 1.11.4 -->

 <!-- LEAFLET -->

<script type="text/javascript">
	$(function(){
		$(".toggle-expand-btn").click(function (e) {
			$(this).closest('.box').toggleClass('panel-fullscreen');
		});
	});
</script>


</body>
</html>

