
    <footer class="container">
       <div class="row">
        <div class="col-sm-6 ">
          <!-- <p><span data-feather="twitter"></span> SAI Studio Alam
          <br/><span data-feather="facebook"></span> Sekolah Alam Indonesia Studio Alam
          <br/><span data-feather="instagram"></span> @saistudal</p> -->
       </div>
       	<div class="col-sm-6 pull-right" style="text-align: right;">
         	<p>Jalan Raden Saleh (Studio Alam TVRI) No 78x
         	<br/>Sukmajaya Depok - Telp <a href="telp:+622177835721">+62 21 77835721</a>
         	<br/>&copy; 2018 Sekolah Alam Indonesia - <a href="<?=base_url()?>Dashboard" style="color:black;text-decoration: none">Studio Alam</a> </p>
       </div>
       
       </div>
    </footer>
    <script type="text/javascript">
    	feather.replace()
    </script>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

  </body>
</html>
